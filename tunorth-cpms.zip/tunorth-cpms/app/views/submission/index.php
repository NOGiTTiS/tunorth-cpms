<?php require_once '../app/views/templates/header.php'; ?>

<div class="flex min-h-screen bg-gray-50">
    <?php include '../app/views/templates/sidebar.php'; ?>

    <div class="flex-1 flex flex-col min-w-0 overflow-hidden">
        <!-- Mobile Header -->
        <header class="md:hidden bg-slate-900 text-white p-4 flex justify-between items-center sticky top-0 z-30 shadow-md">
            <span class="font-bold text-pink-500 tracking-tight">CPMS Submission</span>
            <button onclick="toggleSidebar()" class="p-2 bg-slate-800 rounded-lg">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
            </button>
        </header>

        <main class="flex-1 p-4 md:p-8 overflow-y-auto">
            <div class="max-w-5xl mx-auto">
                
                <div class="mb-8">
                    <h2 class="text-2xl md:text-3xl font-bold text-gray-800">ส่งเอกสารโครงงาน</h2>
                    <div class="mt-2 flex items-center text-pink-600">
                        <span class="text-sm font-bold bg-pink-50 px-3 py-1 rounded-lg border border-pink-100 italic">
                            📁 กลุ่ม: <?php echo htmlspecialchars($data['group']['project_name_th']); ?>
                        </span>
                    </div>
                </div>

                <!-- Table Container -->
                <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead class="bg-slate-50 border-b border-gray-100">
                                <tr>
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">ลำดับ & ขั้นตอน</th>
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">สถานะ</th>
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-center">จัดการ</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-50">
                                <?php foreach($data['steps'] as $step): ?>
                                    <tr class="hover:bg-slate-50/50 transition-colors">
                                        <td class="px-6 py-5 align-top">
                                            <div class="flex items-start">
                                                <!-- ลำดับเลข -->
                                                <div class="w-8 h-8 rounded-lg bg-pink-50 text-pink-500 flex items-center justify-center font-bold text-xs mr-4 shrink-0 mt-1">
                                                    <?php echo $step['step_order']; ?>
                                                </div>
                                                
                                                <div class="min-w-0 flex-1">
                                                    <p class="font-bold text-gray-800 text-sm md:text-base"><?php echo htmlspecialchars($step['step_name']); ?></p>
                                                    
                                                    <?php if($step['submitted_at']): ?>
                                                        <p class="text-[10px] text-gray-400 mt-1 uppercase tracking-tighter">ส่งเมื่อ: <?php echo date('d/m/Y H:i', strtotime($step['submitted_at'])); ?></p>
                                                    <?php endif; ?>

                                                    <!-- แสดงคอมเม้นต์จากครูทันที (ถ้ามี) -->
                                                    <?php if($step['comment']): ?>
                                                        <div class="mt-3 p-3 bg-amber-50 border-l-4 border-amber-400 rounded-r-xl">
                                                            <div class="flex items-center mb-1">
                                                                <span class="text-[10px] font-bold text-amber-600 uppercase tracking-widest">📝 ความเห็นจากครู:</span>
                                                            </div>
                                                            <p class="text-xs text-gray-700 leading-relaxed font-medium">
                                                                <?php echo nl2br(htmlspecialchars($step['comment'])); ?>
                                                            </p>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        
                                        <td class="px-6 py-5 align-top">
                                            <?php 
                                                $badgeClass = "bg-gray-100 text-gray-400";
                                                $text = "ยังไม่ส่ง";
                                                if($step['status'] == 'PENDING') { $badgeClass = "bg-amber-100 text-amber-600"; $text = "รอตรวจ"; }
                                                if($step['status'] == 'APPROVED') { $badgeClass = "bg-green-100 text-green-600"; $text = "ผ่านแล้ว"; }
                                                if($step['status'] == 'REJECTED') { $badgeClass = "bg-rose-100 text-rose-600"; $text = "แก้ไข"; }
                                            ?>
                                            <div class="mt-1">
                                                <span class="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest <?php echo $badgeClass; ?>">
                                                    <?php echo $text; ?>
                                                </span>
                                            </div>
                                        </td>
                                        
                                        <td class="px-6 py-5 align-top text-center">
                                            <div class="flex items-center justify-center">
                                                <!-- ปุ่มอัปโหลด -->
                                                <button onclick="openUploadModal(<?php echo $step['id']; ?>, '<?php echo htmlspecialchars($step['step_name'], ENT_QUOTES); ?>')" 
                                                    class="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-pink-100 active:scale-95 whitespace-nowrap">
                                                    <?php echo ($step['status']) ? 'ส่งใหม่' : 'อัปโหลด'; ?>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="mt-8 p-6 bg-blue-50 rounded-3xl border border-blue-100">
                    <h4 class="text-blue-700 font-bold mb-2 flex items-center text-sm">
                        <span class="mr-2">💡</span> คำแนะนำการส่งงาน
                    </h4>
                    <ul class="text-xs text-blue-600 space-y-1 opacity-80">
                        <li>• รองรับไฟล์ PDF, DOC, DOCX เท่านั้น</li>
                        <li>• ขนาดไฟล์ไม่ควรเกิน 20MB ต่อการอัปโหลด</li>
                        <li>• หากครูให้แก้ไข สถานะจะเปลี่ยนเป็น "แก้ไข" และคุณสามารถส่งใหม่ได้ทันที</li>
                    </ul>
                </div>

            </div>
        </main>
    </div>
</div>

<script>
// ฟังก์ชันอัปโหลดไฟล์ (เรียกใช้ SweetAlert2)
async function openUploadModal(stepId, stepName) {
    const { value: file } = await Swal.fire({
        title: 'อัปโหลด: ' + stepName,
        text: 'กรุณาเลือกไฟล์เอกสารของคุณ',
        input: 'file',
        inputAttributes: { 'accept': '.pdf,.doc,.docx', 'aria-label': 'Upload project file' },
        showCancelButton: true,
        confirmButtonText: 'ส่งงานทันที',
        confirmButtonColor: '#ec4899',
        cancelButtonText: 'ยกเลิก',
        customClass: { popup: 'rounded-3xl' }
    });

    if (file) {
        const formData = new FormData();
        formData.append('csrf_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
        formData.append('project_file', file);
        formData.append('step_id', stepId);
        formData.append('step_name', stepName);
        formData.append('group_id', '<?php echo $data['group']['id']; ?>');
        formData.append('group_name', '<?php echo $data['group']['project_name_th']; ?>');

        Swal.fire({
            title: 'กำลังอัปโหลด...',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        try {
            const res = await fetch('/submission/upload', { method: 'POST', body: formData });
            const result = await res.json();
            if (result.status === 'success') {
                Swal.fire({ icon: 'success', title: 'ส่งงานสำเร็จ!', showConfirmButton: false, timer: 1500 })
                    .then(() => location.reload());
            } else {
                Swal.fire('ผิดพลาด', result.message, 'error');
            }
        } catch (e) {
            Swal.fire('ผิดพลาด', 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้', 'error');
        }
    }
}
</script>

<?php require_once '../app/views/templates/footer.php'; ?>